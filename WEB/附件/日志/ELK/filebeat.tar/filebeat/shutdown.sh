
docker stop filebeat-6.7.0
docker rm filebeat-6.7.0
docker rmi local.harbor.com/library/filebeat-custom:6.7.0
